#include <stdio.h>
#include "print.h"
#include "println.h"

int main() {
	printf("printf: Hello World!\n");
	print("print: Hello World!");
	println("println: Hello World!");
}
