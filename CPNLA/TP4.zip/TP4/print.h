#ifndef PRINT
#define PRINT

#include <stdio.h>

int print(char *str);
#endif

