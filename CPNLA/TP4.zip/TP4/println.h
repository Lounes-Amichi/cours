#ifndef PRINT_LN
#define PRINT_LN

#include <stdio.h>

int println(char *str);
#endif

