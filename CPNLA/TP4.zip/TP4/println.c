#include "println.h"

int println(char * str) {
	printf("%s\n", str);
	return 0;
}
