#include "print.h"



int print(char *str) {
	printf("%s", str);
	return 0;
}

