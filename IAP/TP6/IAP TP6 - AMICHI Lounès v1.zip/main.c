#include "bonbon.h"

int main(){
	Tchaine ch1, ch2;
	int reponse;
	
	strcpy(ch2, "ababfzaxoaaababff");
	
	// test copierChaine
	copierChaine(ch1, ch2);
	printf("\n Chaine copiee: >>%s<<", ch2);
	
	// test validerPreferences

	return 0;
}
