/*********************************B2*************************************/
/* AUTEUR : AMICHI Lounès                                               */
/* DATE : 07/01/2026                                                    */
/* VERSION : 1.0                                                        */
/* DESCRIPTION : Module bonbon			                        */
/* NOM FICHIER : tp5.c	                                                */
/************************************************************************/

#include "bonbon.h"

char * copierChaine(char * dst, const char * str) {
	strcpy(dst, str);
	return dst;
}

int validerPreferences(const char * ch) {
	int i;
	for (i = 0; ch[i] != '\0'; i++)
		if (ch[i] < 'a' || ch[i] > 'z')
			return 0;
	return 1;
}

int rechercherSousChaine(const char * ch, const char * ssch) {
	int i = 0;
	while (ch[i] != '$') {
		int j = 0;
		while (ssch[j] != '$' && ch[i + j] == ssch[j]) {
			j++;
		}
		if (ssch[j] == '$') return i;
		i++;
	}
	return -1;
}

/*int retirerSousChaine(char * ch, const char * ssch) {
	int pos = rechercherSousChaine(ch, ssch);

}*/
